import { MainServer } from './mainserver'

const mainServer = new MainServer();
mainServer.start();
